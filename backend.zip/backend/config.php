<?php
return [
    'db' => [
        'host' => 'localhost',
        'name' => 'art_ratio_rental_app',
        'user' => 'angeluos4',
        'pass' => 'Joly0509523195',
        'charset' => 'utf8mb4',
    ],
    'security' => [
        'allowed_origins' => [
            'http://localhost:5173',
            'https://art-ratio.com'
        ],
        'session_name' => 'art_ratio_session',
        'enforce_https' => true,
    ],
    'auth' => [
        'username_hash' => 'eb04020554c2ef58d633c1c71d7aaf0f789fa5e885ddbd1901498d2f5adf7685',
        'password_hash' => '306c7a94b7ba9d5e467d6bf75bb631ff88a44f7c1ae613717643ccee353ed6d1',
    ],
];
