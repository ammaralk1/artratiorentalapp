<?php
return [
    'db' => [
        'host' => 'localhost',
        'name' => 'art_ratio_rental_app',
        'user' => 'angeluos4',
        'pass' => 'Joly0509523195',
        'charset' => 'utf8mb4',
    ],
    'security' => [
        'allowed_origins' => [
            'https://art-ratio.com',
            'https://www.art-ratio.com'
        ],
        'session_name' => 'art_ratio_session',
        'enforce_https' => true,
    ],
];
