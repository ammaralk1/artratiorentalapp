<?php
return [
    'db' => [
        'host' => 'localhost',
        'name' => 'art_ratio_rental_app',
        'user' => 'angeluos4',
        'pass' => 'Joly0509523195',
        'charset' => 'utf8mb4',
    ],
    'security' => [
        'allowed_origins' => [
            'https://art-ratio.com',
            'https://www.art-ratio.com'
        ],
        'session_name' => 'art_ratio_session',
        'enforce_https' => true,
    ],
    'auth' => [
        'username_hash' => '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918',
        'password_hash' => 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f',
    ],
];
